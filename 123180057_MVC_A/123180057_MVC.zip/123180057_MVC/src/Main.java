public class Main {
    public static void main(String []args){
        MVC_praktikum mvcp = new MVC_praktikum();
    }
}
